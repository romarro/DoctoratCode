﻿from __future__ import division 
import unittest
import numpy as np
from pint import UnitRegistry
um = UnitRegistry()
Q_ = um.Quantity

from diffHXpy import *

class Test_test_HeatExchangers(unittest.TestCase):

    def test_NoFin(self):
        wStr=NoFin(h=1.6,p=10.0,g=0.14,lat=50,lung=300)
        self.assertEqual('NoFin',wStr.Name,'Numele nu este NoFin')
        self.assertAlmostEqual(50*1.6,wStr.Ac,3,'Ac nu este calculat corect')
        self.assertTupleEqual((50*300.,50*300.,0.),wStr.At,'At nu este calculat corect')
        self.assertTrue(isinstance(wStr,Fin))

    def test_Fin_Posargs(self):
        wStr = NoFin(1.6,10.,0.14,lat = 50.,lung=300.)
        self.assertAlmostEqual(1.6,wStr.h,'inaltimea nu este intializata corect')
        self.assertAlmostEqual(1.6,wStr.p,'pasul nu este intializat corect')
        self.assertAlmostEqual(1.6,wStr.g,'grosimea nu este intializata corect')
        self.assertAlmostEqual(1.6,wStr.lat,'latimea nu este intializata corect')
        self.assertAlmostEqual(1.6,wStr.lung,'lungimea nu este intializata corect')
            
    def test_Wavy(self):
        aStr=Wavy(h=9.8,p=5.,g=0.14,lat=300.,lung=50.)
        self.assertEqual('Wavy',aStr.Name,'Numele nu este Wavy')


    def test_CFHeatExchnangers(self):
        pass
        

if __name__ == '__main__':
    unittest.main()
