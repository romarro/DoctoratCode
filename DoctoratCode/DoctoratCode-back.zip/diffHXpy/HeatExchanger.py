﻿from __future__ import division
from enum import Enum
from abc import ABCMeta, abstractmethod, abstractproperty
import numpy as np
from scipy.optimize import brentq
"""
Trebuie sa poata sa primeasca geometria sub forma:
    aerpara={'ha':8.8,
              'pa':5.5,
              'ga':0.14,
              }
    apapara={'hw':2.1,
             'pw':None,
             'gw':None
             }
    heatexch={'Lung':400,
              'Lat':392,
              'Gros':85,
              'gpd':0.5
              'Aerstr':aerpara,
              'Apastr':apapara
              }

    inletpara={'Tci':30,
               'mci':0.123/'vci':2,
               'Thi':85,
               'mhi:.023/'vhi':0.2
               }

    exppara={'Pb':0.985,
             'Rh':30,
             'Tci':30,
             'Tco':35,
             'mci':0.23
             'Qc':15,
             'glyc':0.0,
             'Thi':85,
             'Tho':80
             'mhi':0.3
             'Qh':16.0
             }
    
    ra = CFHeatExchanger('Ra 23433-0',**heatexch,air,water)
    ra.Calculate(**inletpara)

    ra.Interpret(**exppara)

    """

class Fin(object):
    __metaclass__=ABCMeta
    def __init__(self, *args, **kwargs):
        args+=tuple(np.zeros(5-len(args)))
        self.h,self.p,self.g,self.lung,self.lat=args
        self.__dict__.update(**kwargs)
    
    def lunglat(self,lung,lat):
        self.lung=lung
        self.lat=lat
             
    @property
    def Name(self):
        return type(self).__name__

    @abstractproperty
    def Ac(self):
        return

    @abstractproperty
    def At(self):
        return 

class NoFin(Fin):
    def __init__(self, *args, **kwargs):
        return super(NoFin, self).__init__(*args, **kwargs)
   
    @property
    def Ac(self):
        return self.lat*self.h
    
    @property
    def At(self):
        atb = self.lat*self.lung
        return atb,atb,0.0*atb

class Wavy(Fin):    
    @property
    def Ac(self):
        nrpasi=self._lat/self.p
        acp=(self.p-2*self.g)*(self.h-self.g)
        return nrpasi*apc
    @property
    def At(self):
        atb=self._lat*self._lung
        nrpasi=self._lat/self.p
        afin=(self._h-self._g)*self._lung 
        return atb+afin,atb,afin

class Flow(object):
    def __init__(self,name,eps,ntu=None,afset=(0,1)):
        self.Name=name
        self.Eps=eps
        self.NTU=ntu
        self.afset=afset
        if ntu==None:
            def root(n,u):
                return n-self.Eps(n,u)
            def invFunc(n,u):
                f,=brentq(root,0,30,(u,))
                return f
            self.NTU=invFunc

    def FlowSet(self,lung,lat):
        rez=(lung,lat)
        return rez[fset[0]],rez[fset[1]]

    def __str__(self):
        return self.Name


class FlowType(Enum):
    Counter=Flow('CounterFlow',
                 eps=lambda ntu,mu: (1.-np.exp(-ntu*(1.-mu)))/(1.-mu*np.exp(-ntu*(1.-mu))),
                 ntu=lambda eps,mu: 1./(mu-1.)*np.log((mu-1.)/(mu*eps-1.)))
    Echi=Flow('EchiFlow',
              eps=lambda ntu,mu: (1.-np.exp(-ntu*(1.+mu)))/(1.+mu),
              ntu=lambda eps,mu: -np.log(1-eps*(1.+mu))/(1.+mu))
    CrossBothUnmixed=Flow('CrossFlowBothUnmixed',
                          eps = lambda ntu,mu: 1.-np.exp(1./mu*ntu**0.22*(np.exp(-mu*ntu**0.78)-1.)),
                          ntu = None
                          )
    CrossMinUnmixed=Flow('CrossFlowMinUnmixed',
                         eps = lambda ntu,mu: 1./mu*(1.-np.exp(-mu*(1.-np.exp(ntu)))),
                         ntu = lambda eps,mu: -np.log(1.+1./mu*np.log(1.-eps*mu)))
    CrossMaxUnmixed=Flow('CrossFlowMaxUnmixed',
                         eps = lambda ntu,mu: 1.-exp(-1./mu*(1-np.exp(-mu*ntu))),
                         ntu = lambda eps,mu: -1./mu*np.log(mu*np.log(1-eps)+1))

class CFHeatExchanger(object):
    """
    Implementeaza un schimbator de caldura in curent incrucisat folosind ecuatiile diferentiale
    Obs:
    la fiecare punct trebuie schimbata ecuatia cu noile constante. 
    """
    
    def __init__(self, name='',len=400.0,width=400.0,thick=50.0,gpd=0.5,
                 ftype=FlowType.CrossBothUnmixed,
                 strair=Wavy(9.8,5.,0.14),strwater=NoFin(1.6), **kwargs):   
        
        self.Name,self._len,self._width,self._thick,self.gpd=name,len,width,thick,gpd
        self._ftype=ftype
        self._strAir=strair
        self._strAir.lunglat(self._ftype.FlowSet(self._len,self._thick))
        self._strWater=strwater
        self._strWater.lunglat(self._len,self._thick)
        self._afinNo=int((self._width-self.__strAir.h-self.gpd)/Pitch+0.5)+1
        
        if 'AFinNo' in kwargs.keys():
            self.AFinNo=kwargs.pop('AFinNo')

        self._width=(self._afinNo-1)*Pitch+self.__strAir.h+self.gpd
        self.__dict__.update(**kwargs)
   
    @property
    def AFinNo(self):
        return self._afinNo
    @AFinNo.setter
    def AFinNo(self,v):
        self._afinNo=v
        self._width=(self._afinNo-1)*Pitch+self.__strAir.h+self.gpd  

    @property
    def Pitch(self):
        return self.__strAir.h+self.gpd+self.__strWater.h
         
    @property
    def Length(self):
        return self._len
    @Length.setter
    def Length(self,v):
        
        self._len=v
        self._strAir.lunglat(self._ftype.FlowSet(self._len,self._thick))
        self._strWater.lunglat(self._len,self._thick)

    @property
    def Width(self):
        return self._width

    @Width.setter
    def Width(self,v):
        self._afinNo=int((v-self.__strAir.h-self.gpd)/Pitch+0.5)+1
        self._width=self._width=(self._afinNo-1)*Pitch+self.__strAir.h+self.gpd
    
    @property
    def Thick(self):
        return self._thick
    @Thick.setter
    def Thick(self,v):
        self._thick=v
        if self.__strAir:
            self._strAir.lunglat(self._ftype.FlowSet(self._len,self._thick))
        if self.__strWater:
            self._strWa.lunglat(self._len,self._thick)

    @property
    def StrAir(self):
        return self._strAir
    @StrAir.setter
    def StrAir(self,v):
        if not isinstance(v,Fin): raise AttributeError('StrAir has to be of type Fin')
        self._strAir=v
        self._strAir.lunglat(self._ftype.FlowSet(self._len,self._thick))
        self.AFinNo=self._afinNo #force width recalculation keeping the number of channels the same
        
    @property
    def StrWater(self):
        return self._strWater
    @StrWater.setter
    def StrWater(self,v):
        if not isinstance(v,Fin): raise AttributeError('StrWater has to be of type Fin')
        self._strWater=v
        self._strWater.lunglat(self._len,self._thick)   
        self.AFinNo=self._afinNo
    
    def EpsNtuCalculate():
        pass


if __name__=='__main__':

    #imi trebuie un fisier de teste prelucrat pentru a putea dezvolta HeatExchanger
    pass

