from __future__ import division
from collections import *
from fipy import *
from __builtin__ import AttributeError
from inspect import getargspec,getargvalues
from CoolProp.CoolProp import PropsSI,HAPropsSI


class Component(dict):
    #def __getattribute__(self,attr):
    #    val=super(Component,self).__getattribute__(attr)
    #    #vezi : http://stackoverflow.com/questions/4295678/understanding-the-difference-between-getattr-and-getattribute
    #    #ultimele postari
    #    if callable(val):
    #        args=getargspec(val).args
            
    def __getattr__(self,name):
        if name not in self:
            raise AttributeError('atributul nu exista : '+name)
       #if hasattr(self[name],'__call__'):
       #     return self[name](**self)
        return self[name]

    def __setattr__(self,name,value):
        self.update({name:value})

    def __delattr__(self,name):
        del self[name]

#------------------------------------------------------------------------#
#                    Definim fluidele de lucru                           #
#------------------------------------------------------------------------#
class Fluid(dict):
    def __getattr__(self,name):
        if name not in self:
            raise AttributeError('atributul %s nu exista!. Trebuie '+\
                                'initializat inainte de folosire!'%name)
        if name=='init':
            initargs=set(getargspec(self[name][1]).args)
            kwargs=dict((k,self[k]) for k in self.viewkeys()&initargs)
            self.update({self[name][0]:0})
            self[self[name][0]]=self[name][1](**kwargs)
            return lambda :self[self[name][0]]
        val=self[name]
        if callable(val):
            argNames=getargspec(val).args
            kwargs=self.viewkeys() & set(argNames)
            args=dict((k,self[k]) for k in kwargs)
            return val(**args)
        else:
            return val

        return self[name]

    def __setattr__(self,name,value):
        if not str(name).upper()=='NAME':
            self.update({name:value})
    
    def _delattr__(self,name):
        del self[name]


aer=Fluid(name='Aer',T=30.0,P=0.998,Rh=0.4
          ,init = ('abs',lambda T,P,Rh:HAPropsSI('W','T',T+273.15,'P',P*1e5,'R',Rh))     #[kg water/kg dry air]
          ,rho = lambda T,P,abs:1.0/HAPropsSI('V','T',T+273.15,'P',P*1e5,'W',abs)         #[kg dry air/m^3]
          ,cp=lambda T,P,abs:HAPropsSI('C','T',T+273.15,'P',P*1e5,'W',abs)                #[J/kg dry air/K]
          ,cond=lambda T,P,abs:HAPropsSI('K','T',T+273.15,'P',P*1e5,'W',abs)             #[W/m/K]
          ,visc=lambda T,P,abs:HAPropsSI('M','T',T+273.15,'P',P*1e5,'W',abs)             #[Pa*s]
          ,Pr = lambda T,P,abs:HAPropsSI('M','T',T+273.15,'P',P*1e5,'W',abs)*HAPropsSI('C','T',T+273.15,'P',P*1e5,'W',abs)/HAPropsSI('K','T',T+273.15,'P',P*1e5,'W',abs)
          )

apa=Fluid(name='Apa',T=85.0,P=2,conc=0.5
          ,init = ('fldname',lambda conc:'Water' if conc==0 else 'INCOMP::AEG[%.2F]'%conc)
          ,rho = lambda T,P,fldname : PropsSI('D','T',T+273.15,'P',P*1e5,fldname)       #[kg/m^3]
          ,cp = lambda T,P,fldname : PropsSI('C','T',T+273.15,'P',P*1e5,fldname)        #[J/kg/k]
          ,cond = lambda T,P,fldname : PropsSI('L','T',T+273.15,'P',P*1e5,fldname)      #[W/m/K]
          ,visc = lambda T,P,fldname : PropsSI('V','T',T+273.15,'P',P*1e5,fldname)      #[Pa*s]
          ,Pr = lambda T,P,fldname :PropsSI('V','T',T+273.15,'P',P*1e5,fldname)*PropsSI('C','T',T+273.15,'P',P*1e5,fldname)/PropsSI('L','T',T+273.15,'P',P*1e5,fldname)
          )


print('aer test:')
aer.init()
print 'rho ',aer.rho
print 'cp ',aer.cp
print 'cond ',aer.cond
print 'visc ',aer.visc
print 'Pr ',aer.Pr
print('apa chioara')
apa.conc=0.0
apa.init()
print 'rho ',apa.rho
print 'cp ',apa.cp
print 'cond ',apa.cond
print 'visc ',apa.visc
print 'Pr ',apa.Pr
print('apa glycol 0.5')
apa.conc=0.5
apa.init()
print 'rho ',apa.rho
print 'cp ',apa.cp
print 'cond ',apa.cond
print 'visc ',apa.visc
print 'Pr ',apa.Pr
#------------------------------------------------------------#
#          Definim structura necesara pentru                 #
#            calculul schimbatorului                         #
#------------------------------------------------------------#

#-----------------Ariile aripioarei ondulate -------------------#

def WAc(h,p,g,pl,lat,**kwargs):
    """
    Calculeaza aria de curgere pentru o aripioara ondulata.
    lungimea este lungimea de curgere (normal pe vectorul curgere)
    latimea este latimea de curgere (perpendicular pe vectorul curgere)
    """
    nrpasi=lat/p
    return nrpasi*(h-g)*(p-2*g)

def WPu(h,p,g,pl,lat,**kwargs):
    """
    Perimetrul udat pe toata latimea de curgere
    """
    nrpasi=lat/p
    return 2*((h-g)+(p/2.-g))*nrpasi

def Dh(h,p,g,pl,lat,**kwargs):
    return 4*WAc(h,p,g,pl,lat,**kwargs)/WPu(h,p,g,pl,lat,**kwargs)

def WAtb(h,p,g,pl,lung,lat,**kwargs):
    return 2*lung*lat

def WAtf(h,p,g,pl,lung,**kwargs):
    """
    Intoarce aria de schimb termic al unui pas de  aripioara
    are 4 fete de lamela
    """
    return 4*(h-g)*lung

def WAt(h,p,g,pl,lung,lat,**kwargs):
    nrpasi=lat/p
    return WAtb(h,p,g,pl,lung,lat,**kwargs)+nrpasi*WAtf(h,p,g,pl,lung,**kwargs)

#-------------------Definim structura---------------------------#
WavyFin=Component(h=9.8,p=5.,g=0.14,pl=10.,lung=200.,lat=50.,eff=0.998)
RectFin=Component(h=9.8,p=5.,g=0.14,pl=10.,lung=200.,lat=50.,eff=1.0)
Ra=Component(nume='Ra 1234-0',
               lung=200.,lat=400.,gros=50.,gpd=0.5,pl=3.,
               aerStr=WavyFin,
               apaStr=RectFin)

def HXStructCalc(struct=Ra):
    """
    Calculeaza structura si introduce noi 
    """
    struct.aerStr.update(lung=struct.gros,lat=struct.lung)
    struct.apaStr.update(lung=struct.lung,lat=struct.gros)

    struct.aerStr.update(Ac=WAc(**struct.aerStr),
                         Pu=WPu(**struct.aerStr),
                         Atb=WAtb(**struct.aerStr),
                         Atf=WAtf(**struct.aerStr),
                         At=WAt(**struct.aerStr))
    
    struct.apaStr.update(Ac=WAc(**struct.apaStr),
                         Pu=WPu(**struct.apaStr),
                         Atb=WAtb(**struct.apaStr),
                         Atf=WAtf(**struct.apaStr),
                         At=WAt(**struct.apaStr))
    
    #struct.update(Pitch=0.0,aFinNo=0,Ata=0.0,Atw=0.0,Aca=0.0,Acw=0.0)
    struct.Pitch=struct.aerStr.h+struct.gpd+struct.apaStr.h
    struct.aFinNo=int((struct.lat-2*struct.pl-struct.gpd-struct.aerStr.h)/struct.Pitch)+1
    struct.lat=(struct.aFinNo+1)*struct.Pitch+2*struct.pl+struct.aerStr.h
    struct.Ata=struct.aFinNo*struct.aerStr.At
    struct.Atw=(struct.aFinNo-1)*struct.apaStr.At
    struct.Aca=struct.aFinNo*struct.aerStr.Ac
    struct.Acw=(struct.aFinNo-1)*struct.apaStr.Ac
"""
Datele de test sunt luate din [1] cu o diferenta: mediul cald este luat ca fiind apa
[1] EIROLA, T., & TUOMELA, J. (2002). MATHEMATICAL MODEL FOR SINGLE-PASS CROSSFLOW HEAT EXCHANGER. In Industrial Mathematics Workshop. 
Tampere: Tampere University of Technology. Retrieved from http://www.math.tut.fi/workshop02/TMSystemsReport.pdf


"""
 
Ra.update(Tai=30.0,ma=24.3,Twi=85.0,mw=28.0)

def HXThermalCalc(struct=Ra):
    pass

HXStructCalc(Ra)
pass





    

